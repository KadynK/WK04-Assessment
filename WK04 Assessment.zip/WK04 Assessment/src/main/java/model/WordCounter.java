package model;

/*
 * Kadyn Krutsch - kkrutsch
 * CIS175
 * Feb 24, 2024
 */
public class WordCounter {
	private int characters;
	private int words;
	private int spaces;
	private String statement;

	
	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
		setWordsInStatement(statement); //NOTICE THIS METHOD CALL
	}

	public WordCounter() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public WordCounter(String statement) {
		super();
		this.statement = statement;
		setWordsInStatement(statement); //NOTICE THIS METHOD CALL
	}
	
	public int getCharacters() {
		return characters;
	}
	public void setCharacters(int characters) {
		this.characters = characters;
	}
	
	public int getWords() {
		return words;
	}

	public void setWords(int words) {
		this.words = words;
	}

	public int getSpaces() {
		return spaces;
	}

	public void setSpaces(int spaces) {
		this.spaces = spaces;
	}


	public void setWordsInStatement(String statement) {
		int words = 1;
		int spaces = 0;
		int characters = 0;
		
		for (int i = 0; i < statement.length(); i++) {
			characters++;
			setCharacters(characters);
			if (statement.charAt(i) == ' ') {
				spaces++;
				setSpaces(spaces);
				if (statement.charAt(i + 1) != ' ') {
					words++;
				}
				setWords(words);
			}
		}
	}
	
	@Override
	public String toString() {
	return "WordCounter [characters=" + characters + ", words=" + words + ", spaces=" + spaces + "]";
	}
}
